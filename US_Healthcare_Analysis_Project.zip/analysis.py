#!/usr/bin/env python3
"""US healthcare case study: clean, explore, test, forecast, and model the supplied file."""

from pathlib import Path
import json
import warnings

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
from sklearn.compose import ColumnTransformer
from sklearn.linear_model import LogisticRegression, Ridge
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    mean_absolute_error,
    r2_score,
    roc_auc_score,
)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from statsmodels.tsa.holtwinters import ExponentialSmoothing

warnings.filterwarnings("ignore")

SRC = Path("Healthcare_Data.csv")
OUT = Path(".")
FIG = OUT / "figures"
OUT.mkdir(parents=True, exist_ok=True)
FIG.mkdir(parents=True, exist_ok=True)

NAVY = "#1B4F72"
TEAL = "#148F77"
CORAL = "#C0392B"
GOLD = "#B9770E"
SLATE = "#5D6D7E"
PAL = ["#1B4F72", "#148F77", "#B9770E", "#C0392B", "#5D6D7E", "#1A5276"]

plt.rcParams.update({
    "figure.facecolor": "white",
    "axes.facecolor": "white",
    "axes.edgecolor": "#D5D8DC",
    "axes.spines.top": False,
    "axes.spines.right": False,
    "axes.labelcolor": "#1C2833",
    "xtick.color": "#1C2833",
    "ytick.color": "#1C2833",
    "text.color": "#1C2833",
    "font.size": 11,
    "axes.titlesize": 13,
    "axes.titleweight": "semibold",
    "axes.labelsize": 11,
    "figure.dpi": 140,
    "savefig.dpi": 160,
    "savefig.bbox": "tight",
})
sns.set_palette(PAL)


def save(fig, name):
    path = FIG / name
    fig.savefig(path)
    plt.close(fig)
    return str(path)


raw = pd.read_csv(SRC)
raw.columns = [c.strip() for c in raw.columns]
raw = raw.loc[:, ~raw.columns.str.startswith("Unnamed")]
n_raw = len(raw)

df = raw.copy()
df["Gender"] = df["Gender"].astype(str).str.strip().replace({"M": "Male", "F": "Female", "male": "Male", "female": "Female"})
df["Medical Condition"] = df["Medical Condition"].astype(str).str.strip().str.lower().str.title()
df["Admission Type"] = df["Admission Type"].astype(str).str.strip().replace({"Emer": "Emergency"})
blood_map = {
    "A+": "A+", "A+ve": "A+", "A-": "A-",
    "B+": "B+", "B+ve": "B+", "B-": "B-",
    "AB+": "AB+", "AB-": "AB-", "AB negative": "AB-",
    "O+": "O+", "O+ve": "O+", "0+": "O+", "O-": "O-", "O neg": "O-",
}
df["Blood Type"] = df["Blood Type"].str.strip().map(lambda x: blood_map.get(x, x))
df["Age"] = pd.to_numeric(df["Age"], errors="coerce")
df["Billing Amount"] = pd.to_numeric(df["Billing Amount"], errors="coerce")
df["Date of Admission"] = pd.to_datetime(df["Date of Admission"], dayfirst=True, errors="coerce")
df["Discharge Date"] = pd.to_datetime(df["Discharge Date"], dayfirst=True, errors="coerce")
df["Length of Stay"] = (df["Discharge Date"] - df["Date of Admission"]).dt.days
bad_los = int((df["Length of Stay"] < 0).sum())
df.loc[df["Length of Stay"] < 0, "Length of Stay"] = np.nan

billing_missing = int(df["Billing Amount"].isna().sum())
med_median = df.groupby("Medical Condition")["Billing Amount"].transform("median")
df["Billing Imputed"] = df["Billing Amount"].isna()
df["Billing Amount"] = df["Billing Amount"].fillna(med_median)
df["Cost per Day"] = df["Billing Amount"] / df["Length of Stay"].replace(0, np.nan)

bins = [0, 30, 45, 60, 75, 120]
labels = ["18-30", "31-45", "46-60", "61-75", "76+"]
df["Age Group"] = pd.cut(df["Age"], bins=bins, labels=labels, right=True)
df["Year"] = df["Date of Admission"].dt.year
df["Month"] = df["Date of Admission"].dt.to_period("M").dt.to_timestamp()
df["Abnormal"] = (df["Test Results"] == "Abnormal").astype(int)
df["Repeat Name"] = df.groupby("Name")["Name"].transform("size") > 1

# Outliers on billing (IQR). Kept in analysis; flagged only.
q1, q3 = df["Billing Amount"].quantile([0.25, 0.75])
iqr = q3 - q1
lo, hi = q1 - 1.5 * iqr, q3 + 1.5 * iqr
df["Billing Outlier"] = (df["Billing Amount"] < lo) | (df["Billing Amount"] > hi)

df.to_csv(OUT / "cleaned_healthcare.csv", index=False)

# ---------- summaries ----------
cond_tbl = (
    df.groupby("Medical Condition")
    .agg(
        admissions=("Name", "size"),
        mean_bill=("Billing Amount", "mean"),
        median_bill=("Billing Amount", "median"),
        mean_los=("Length of Stay", "mean"),
        abnormal_rate=("Abnormal", "mean"),
    )
    .sort_values("admissions", ascending=False)
)
cond_tbl.to_csv(OUT / "condition_summary.csv")

ins_tbl = (
    df.groupby("Insurance Provider")
    .agg(
        admissions=("Name", "size"),
        mean_bill=("Billing Amount", "mean"),
        median_bill=("Billing Amount", "median"),
        mean_los=("Length of Stay", "mean"),
        abnormal_rate=("Abnormal", "mean"),
    )
    .sort_values("admissions", ascending=False)
)
ins_tbl.to_csv(OUT / "insurance_summary.csv")

age_cond = pd.crosstab(df["Age Group"], df["Medical Condition"], normalize="index") * 100
age_cond.to_csv(OUT / "disease_by_age_pct.csv")

# Hospital performance proxy. No satisfaction or mortality fields exist.
hosp = (
    df.groupby("Hospital")
    .agg(
        admissions=("Name", "size"),
        mean_bill=("Billing Amount", "mean"),
        mean_los=("Length of Stay", "mean"),
        abnormal_rate=("Abnormal", "mean"),
        repeat_name_rate=("Repeat Name", "mean"),
    )
)
hosp_f = hosp[hosp["admissions"] >= 8].copy()
hosp_f["bill_z"] = (hosp_f["mean_bill"] - hosp_f["mean_bill"].mean()) / hosp_f["mean_bill"].std()
hosp_f["los_z"] = (hosp_f["mean_los"] - hosp_f["mean_los"].mean()) / hosp_f["mean_los"].std()
hosp_f["abn_z"] = (hosp_f["abnormal_rate"] - hosp_f["abnormal_rate"].mean()) / hosp_f["abnormal_rate"].std()
hosp_f["pressure_score"] = hosp_f[["bill_z", "los_z", "abn_z"]].mean(axis=1)
hosp_f.sort_values("pressure_score", ascending=False).to_csv(OUT / "hospital_performance.csv")

# ---------- stats ----------
ct_gender = pd.crosstab(df["Gender"], df["Test Results"])
chi_g, p_g, dof_g, _ = stats.chi2_contingency(ct_gender)
ct_cond = pd.crosstab(df["Medical Condition"], df["Test Results"])
chi_c, p_c, dof_c, _ = stats.chi2_contingency(ct_cond)
groups = [g["Billing Amount"].dropna().values for _, g in df.groupby("Medical Condition")]
anova_f, anova_p = stats.f_oneway(*groups)
groups_ins = [g["Billing Amount"].dropna().values for _, g in df.groupby("Insurance Provider")]
anova_ins_f, anova_ins_p = stats.f_oneway(*groups_ins)
corr = df[["Age", "Billing Amount", "Length of Stay", "Abnormal", "Cost per Day"]].corr()
corr.to_csv(OUT / "correlation.csv")

# ---------- forecast ----------
monthly = (
    df.dropna(subset=["Month"])
    .groupby("Month")
    .agg(admissions=("Name", "size"), total_bill=("Billing Amount", "sum"), mean_bill=("Billing Amount", "mean"))
    .asfreq("MS")
)
monthly["admissions"] = monthly["admissions"].fillna(0)
monthly["total_bill"] = monthly["total_bill"].interpolate()
monthly["mean_bill"] = monthly["mean_bill"].interpolate()
series = monthly["total_bill"].astype(float)
hw = ExponentialSmoothing(
    series, trend="add", seasonal="add", seasonal_periods=12, initialization_method="estimated"
).fit(optimized=True)
forecast = hw.forecast(6)
monthly.to_csv(OUT / "monthly_billing.csv")
forecast.to_csv(OUT / "forecast_6m.csv", header=["total_bill"])

# ---------- models ----------
model_df = df.dropna(subset=["Length of Stay", "Age Group", "Year"]).copy()
features_num = ["Age", "Length of Stay"]
features_cat = ["Gender", "Blood Type", "Medical Condition", "Insurance Provider", "Admission Type", "Medication", "Age Group"]
X = model_df[features_num + features_cat]
y_reg = model_df["Billing Amount"]
y_clf = model_df["Abnormal"]
Xtr, Xte, ytr, yte = train_test_split(X, y_reg, test_size=0.2, random_state=42)
_, _, ytr_c, yte_c = train_test_split(X, y_clf, test_size=0.2, random_state=42)

pre = ColumnTransformer([
    ("num", StandardScaler(), features_num),
    ("cat", OneHotEncoder(handle_unknown="ignore"), features_cat),
])
ridge = Pipeline([("pre", pre), ("model", Ridge(alpha=1.0))])
ridge.fit(Xtr, ytr)
pred = ridge.predict(Xte)
reg_metrics = {
    "mae": float(mean_absolute_error(yte, pred)),
    "r2": float(r2_score(yte, pred)),
    "baseline_mae": float(mean_absolute_error(yte, np.full_like(yte, ytr.mean(), dtype=float))),
}

logit = Pipeline([
    ("pre", pre),
    ("model", LogisticRegression(max_iter=400, class_weight="balanced")),
])
logit.fit(Xtr, ytr_c)
proba = logit.predict_proba(Xte)[:, 1]
pred_c = (proba >= 0.5).astype(int)
clf_metrics = {
    "accuracy": float(accuracy_score(yte_c, pred_c)),
    "roc_auc": float(roc_auc_score(yte_c, proba)),
    "base_rate": float(yte_c.mean()),
}
# coefficients for interpretation
ohe = logit.named_steps["pre"].named_transformers_["cat"]
cat_names = list(ohe.get_feature_names_out(features_cat))
coef = logit.named_steps["model"].coef_.ravel()
names = features_num + cat_names
coef_s = pd.Series(coef, index=names).sort_values(key=np.abs, ascending=False)
coef_s.head(15).to_csv(OUT / "logit_top_coefficients.csv", header=["coef"])

# ---------- plots ----------
fig, ax = plt.subplots(figsize=(8.2, 4.6))
ax.hist(df["Billing Amount"], bins=40, color=NAVY, alpha=0.9, edgecolor="white")
ax.axvline(df["Billing Amount"].median(), color=GOLD, lw=2, label=f"Median ${df['Billing Amount'].median():,.0f}")
ax.axvline(df["Billing Amount"].mean(), color=CORAL, lw=2, ls="--", label=f"Mean ${df['Billing Amount'].mean():,.0f}")
ax.set_title("Billing amount is spread widely, not clustered")
ax.set_xlabel("Billing amount (USD)")
ax.set_ylabel("Admissions")
ax.legend(frameon=False)
save(fig, "01_billing_distribution.png")

fig, ax = plt.subplots(figsize=(8.2, 4.8))
order = cond_tbl.sort_values("mean_bill").index
sns.boxplot(
    data=df, y="Medical Condition", x="Billing Amount", order=order,
    color="#D4E6F1", fliersize=2, ax=ax,
)
ax.set_title("Billing by medical condition")
ax.set_xlabel("Billing amount (USD)")
ax.set_ylabel("")
save(fig, "02_billing_by_condition.png")

fig, ax = plt.subplots(figsize=(8.6, 4.6))
ax.plot(monthly.index, monthly["total_bill"] / 1e6, color=NAVY, lw=2, label="Observed total")
ax.plot(forecast.index, forecast.values / 1e6, color=CORAL, lw=2, ls="--", label="6-month forecast")
ax.set_title("Monthly billed amount and six-month forecast")
ax.set_ylabel("Total billed ($ millions)")
ax.legend(frameon=False)
fig.autofmt_xdate()
save(fig, "03_monthly_trend_forecast.png")

fig, axes = plt.subplots(1, 2, figsize=(9.2, 4.4))
axes[0].hist(df["Age"], bins=20, color=TEAL, edgecolor="white")
axes[0].set_title("Age is nearly uniform, 18 to 85")
axes[0].set_xlabel("Age")
axes[0].set_ylabel("Patients")
gender_counts = df["Gender"].value_counts()
axes[1].bar(gender_counts.index, gender_counts.values, color=[NAVY, TEAL])
axes[1].set_title("Gender mix after cleaning")
axes[1].set_ylabel("Admissions")
fig.tight_layout()
save(fig, "04_age_gender.png")

fig, ax = plt.subplots(figsize=(8.4, 4.8))
sns.heatmap(age_cond.round(1), annot=True, fmt=".1f", cmap="Blues", ax=ax, cbar_kws={"label": "% of age group"})
ax.set_title("Condition share within each age group (%)")
ax.set_xlabel("")
ax.set_ylabel("")
save(fig, "05_disease_by_age.png")

fig, axes = plt.subplots(1, 2, figsize=(9.4, 4.6))
ins_order = ins_tbl.sort_values("mean_bill").index
sns.barplot(data=df, y="Insurance Provider", x="Billing Amount", order=ins_order, estimator=np.mean, errorbar=("ci", 95), color=NAVY, ax=axes[0])
axes[0].set_title("Mean bill by insurer (95% CI)")
axes[0].set_xlabel("Mean billing (USD)")
axes[0].set_ylabel("")
adm = df.groupby("Admission Type")["Billing Amount"].mean().sort_values()
axes[1].barh(adm.index, adm.values, color=TEAL)
axes[1].set_title("Mean bill by admission type")
axes[1].set_xlabel("Mean billing (USD)")
fig.tight_layout()
save(fig, "06_cost_drivers.png")

fig, ax = plt.subplots(figsize=(8.2, 4.6))
los_order = df.groupby("Medical Condition")["Length of Stay"].mean().sort_values().index
sns.boxplot(data=df, y="Medical Condition", x="Length of Stay", order=los_order, color="#D5F5E3", fliersize=2, ax=ax)
ax.set_title("Length of stay by condition")
ax.set_xlabel("Days")
ax.set_ylabel("")
save(fig, "07_los_by_condition.png")

fig, ax = plt.subplots(figsize=(7.6, 4.6))
outcome = pd.crosstab(df["Gender"], df["Test Results"], normalize="index") * 100
outcome = outcome[["Normal", "Inconclusive", "Abnormal"]]
outcome.plot(kind="bar", stacked=True, ax=ax, color=["#148F77", "#B9770E", "#C0392B"], width=0.7)
ax.set_title("Test-result mix is almost the same by gender")
ax.set_ylabel("Share of admissions (%)")
ax.set_xlabel("")
ax.legend(frameon=False, ncol=3)
ax.set_xticklabels(ax.get_xticklabels(), rotation=0)
save(fig, "08_outcome_by_gender.png")

fig, ax = plt.subplots(figsize=(6.4, 5.2))
sns.heatmap(corr, annot=True, fmt=".2f", cmap="RdBu_r", center=0, ax=ax, vmin=-1, vmax=1)
ax.set_title("Correlations are weak")
save(fig, "09_correlation.png")

fig, ax = plt.subplots(figsize=(8.0, 5.0))
ax.scatter(hosp_f["admissions"], hosp_f["abnormal_rate"] * 100, s=hosp_f["mean_bill"] / 80, c=NAVY, alpha=0.75)
ax.axhline(df["Abnormal"].mean() * 100, color=CORAL, ls="--", label="Overall abnormal rate")
ax.set_title("Hospitals with at least 8 admissions")
ax.set_xlabel("Admissions in file")
ax.set_ylabel("Abnormal test rate (%)")
ax.legend(frameon=False)
save(fig, "10_hospital_performance.png")

fig, ax = plt.subplots(figsize=(6.6, 5.4))
ax.scatter(yte, pred, s=12, alpha=0.35, color=NAVY)
lims = [min(yte.min(), pred.min()), max(yte.max(), pred.max())]
ax.plot(lims, lims, color=CORAL, lw=1.5)
ax.set_title(f"Billing model barely beats the mean (R² = {reg_metrics['r2']:.3f})")
ax.set_xlabel("Actual billing (USD)")
ax.set_ylabel("Predicted billing (USD)")
save(fig, "11_model_actual_vs_predicted.png")

med_ct = pd.crosstab(df["Medical Condition"], df["Medication"], normalize="index") * 100
fig, ax = plt.subplots(figsize=(8.4, 4.8))
sns.heatmap(med_ct.round(1), annot=True, fmt=".1f", cmap="Greens", ax=ax)
ax.set_title("Medication mix is flat across conditions (%)")
ax.set_xlabel("")
ax.set_ylabel("")
save(fig, "12_medication_by_condition.png")

# ---------- findings ----------
top_hosp = hosp_f.sort_values("pressure_score", ascending=False).head(5)
low_hosp = hosp_f.sort_values("pressure_score", ascending=True).head(5)
findings = {
    "n_raw": int(n_raw),
    "n_clean": int(len(df)),
    "billing_missing": billing_missing,
    "bad_los": bad_los,
    "billing_outliers": int(df["Billing Outlier"].sum()),
    "date_min": str(df["Date of Admission"].min().date()),
    "date_max": str(df["Date of Admission"].max().date()),
    "mean_bill": float(df["Billing Amount"].mean()),
    "median_bill": float(df["Billing Amount"].median()),
    "std_bill": float(df["Billing Amount"].std()),
    "total_bill": float(df["Billing Amount"].sum()),
    "mean_los": float(df["Length of Stay"].mean()),
    "median_los": float(df["Length of Stay"].median()),
    "abnormal_rate": float(df["Abnormal"].mean()),
    "inconclusive_rate": float((df["Test Results"] == "Inconclusive").mean()),
    "normal_rate": float((df["Test Results"] == "Normal").mean()),
    "female_share": float((df["Gender"] == "Female").mean()),
    "male_share": float((df["Gender"] == "Male").mean()),
    "age_min": int(df["Age"].min()),
    "age_max": int(df["Age"].max()),
    "age_mean": float(df["Age"].mean()),
    "repeat_name_share": float(df["Repeat Name"].mean()),
    "unique_names": int(df["Name"].nunique()),
    "unique_hospitals": int(df["Hospital"].nunique()),
    "hospitals_ge8": int(len(hosp_f)),
    "chi_gender_stat": float(chi_g),
    "chi_gender_p": float(p_g),
    "chi_cond_stat": float(chi_c),
    "chi_cond_p": float(p_c),
    "anova_cond_f": float(anova_f),
    "anova_cond_p": float(anova_p),
    "anova_ins_f": float(anova_ins_f),
    "anova_ins_p": float(anova_ins_p),
    "corr_age_bill": float(corr.loc["Age", "Billing Amount"]),
    "corr_los_bill": float(corr.loc["Length of Stay", "Billing Amount"]),
    "corr_age_abn": float(corr.loc["Age", "Abnormal"]),
    "reg": reg_metrics,
    "clf": clf_metrics,
    "condition": cond_tbl.round(2).reset_index().to_dict(orient="records"),
    "insurance": ins_tbl.round(2).reset_index().to_dict(orient="records"),
    "gender_bill": df.groupby("Gender")["Billing Amount"].mean().round(2).to_dict(),
    "admission_counts": df["Admission Type"].value_counts().to_dict(),
    "admission_bill": df.groupby("Admission Type")["Billing Amount"].mean().round(2).to_dict(),
    "age_bill": df.groupby("Age Group", observed=True)["Billing Amount"].mean().round(2).to_dict(),
    "age_abn": df.groupby("Age Group", observed=True)["Abnormal"].mean().round(4).to_dict(),
    "forecast": {str(k.date()): float(v) for k, v in forecast.items()},
    "hw_aic": float(hw.aic),
    "top_pressure_hospitals": top_hosp.round(3).reset_index().to_dict(orient="records"),
    "low_pressure_hospitals": low_hosp.round(3).reset_index().to_dict(orient="records"),
    "blood_counts": df["Blood Type"].value_counts().to_dict(),
    "monthly_mean": float(monthly["total_bill"].mean()),
    "monthly_last": float(monthly["total_bill"].iloc[-1]),
    "yearly": df.groupby("Year").agg(admissions=("Name", "size"), total_bill=("Billing Amount", "sum"), mean_bill=("Billing Amount", "mean")).round(2).reset_index().astype({"Year": int}).to_dict(orient="records"),
}
# age group keys may be categorical
findings["age_bill"] = {str(k): v for k, v in findings["age_bill"].items()}
findings["age_abn"] = {str(k): float(v) for k, v in findings["age_abn"].items()}
(OUT / "findings.json").write_text(json.dumps(findings, indent=2, default=str))
print(json.dumps({k: findings[k] for k in [
    "n_raw", "billing_missing", "bad_los", "mean_bill", "median_bill", "mean_los",
    "abnormal_rate", "chi_gender_p", "anova_cond_p", "corr_age_bill", "corr_los_bill",
    "reg", "clf", "date_min", "date_max", "hospitals_ge8"
]}, indent=2))
print("figures", len(list(FIG.glob('*.png'))))
